/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-B06
 */

#ifndef xconfig_app_ble_uartlog__
#define xconfig_app_ble_uartlog__



#endif /* xconfig_app_ble_uartlog__ */ 
